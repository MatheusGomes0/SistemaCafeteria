/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author mathe
 */
public class ItensPedido {

    
    private int Cod_item;
    private int qtn_itens;

    public int getCod_item() {
        return Cod_item;
    }

    public void setCod_item(int Cod_item) {
        this.Cod_item = Cod_item;
    }

    public int getQtn_itens() {
        return qtn_itens;
    }

    public void setQtn_itens(int qtn_itens) {
        this.qtn_itens = qtn_itens;
    }
    
}
